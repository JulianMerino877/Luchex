import { Component, signal } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { signOut } from 'firebase/auth';
import { auth } from '../firebase';

@Component({
  selector: 'app-panel',
  imports: [RouterLink, RouterLinkActive, RouterOutlet],
  templateUrl: './panel.html',
  styleUrl: './panel.scss',
})
export class Panel {
  protected readonly collapsed = signal(false);
  protected readonly mobileOpen = signal(false);
  protected readonly signingOut = signal(false);
  protected readonly logoutError = signal('');
  protected readonly modules = [
    { label: 'Clientes', path: '/clientes' },
    { label: 'Inventario', path: '/inventario' },
    { label: 'Órdenes', path: '/ordenes' },
    { label: 'Ventas', path: '/ventas' },
    { label: 'Mecánicos', path: '/mecanicos' },
    { label: 'Reportes', path: '/reportes' },
  ];

  constructor(private readonly router: Router) {}

  protected async logout(): Promise<void> {
    if (this.signingOut()) return;
    this.signingOut.set(true);
    this.logoutError.set('');
    try {
      await signOut(auth);
      await this.router.navigateByUrl('/login');
    } catch {
      this.logoutError.set('No se pudo cerrar sesión. Inténtalo nuevamente.');
    } finally {
      this.signingOut.set(false);
    }
  }
}
