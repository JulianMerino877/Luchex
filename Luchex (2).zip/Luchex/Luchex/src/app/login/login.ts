import { Component, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../firebase';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule],
  templateUrl: './login.html',
  styleUrl: './login.scss',
})
export class LoginComponent {
  protected readonly form = new FormBuilder().nonNullable.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6)]],
  });
  protected readonly error = signal('');
  protected readonly isLoading = signal(false);
  protected readonly passwordVisible = signal(false);

  constructor(private readonly router: Router) {}

  protected async submit(): Promise<void> {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.error.set('');
    this.isLoading.set(true);

    try {
      const { email, password } = this.form.getRawValue();
      await signInWithEmailAndPassword(auth, email, password);
      await this.router.navigateByUrl('/inventario');
    } catch (error: unknown) {
      this.error.set(this.getErrorMessage(error));
    } finally {
      this.isLoading.set(false);
    }
  }

  private getErrorMessage(error: unknown): string {
    const code = typeof error === 'object' && error !== null && 'code' in error ? error.code : '';

    if (code === 'auth/invalid-credential') {
      return 'El correo o la contraseña no son correctos.';
    }

    if (code === 'auth/too-many-requests') {
      return 'Demasiados intentos. Espera unos minutos e inténtalo de nuevo.';
    }

    if (code === 'auth/operation-not-allowed') {
      return 'Activa Correo electrónico/Contraseña en Firebase Authentication.';
    }

    if (code === 'auth/network-request-failed') {
      return 'No hay conexión con Firebase. Revisa tu conexión a internet.';
    }

    return 'No fue posible iniciar sesión. Inténtalo nuevamente.';
  }
}
