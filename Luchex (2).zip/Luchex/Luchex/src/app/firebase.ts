import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: 'AIzaSyClMA7_BCVolRtj4h_IZRKp55YTWODCFK4',
  authDomain: 'luchex-56ec6.firebaseapp.com',
  projectId: 'luchex-56ec6',
  storageBucket: 'luchex-56ec6.firebasestorage.app',
  messagingSenderId: '706936938685',
  appId: '1:706936938685:web:6ca8a13c9e8493d17e97d4',
  measurementId: 'G-5D3253Q66N'
};

export const firebaseApp = initializeApp(firebaseConfig);
export const auth = getAuth(firebaseApp);
export const firestore = getFirestore(firebaseApp);
