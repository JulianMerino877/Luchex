import { Routes } from '@angular/router';
import { LoginComponent } from './login/login';
import { Panel } from './panel/panel';

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: '', pathMatch: 'full', redirectTo: 'login' },
  {
    path: '',
    component: Panel,
    children: [
      { path: 'clientes', loadComponent: () => import('./clientes/clientes').then(m => m.Clientes) },
      { path: 'inventario', loadComponent: () => import('./inventario/inventario').then(m => m.Inventario) },
      { path: 'ordenes', loadComponent: () => import('./ordenes/ordenes').then(m => m.Ordenes) },
      { path: 'ventas', loadComponent: () => import('./ventas/ventas').then(m => m.Ventas) },
      { path: 'mecanicos', loadComponent: () => import('./mecanicos/mecanicos').then(m => m.Mecanicos) },
      { path: 'reportes', loadComponent: () => import('./reportes/reportes').then(m => m.Reportes) },
    ],
  },
  { path: '**', redirectTo: 'login' },
];
